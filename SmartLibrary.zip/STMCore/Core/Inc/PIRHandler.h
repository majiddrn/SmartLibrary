#ifndef PIRHANDLER_H
#define PIRHANDLER_H

#include "main.h"
#include "CommonHandlers.h"
#include "cmsis_os.h"

int doPIRFunc(Message pirMessage);

#endif
