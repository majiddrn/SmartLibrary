#ifndef RTOSHANDLER_H
#define RTOSHANDLER_H

#include "SensorsModulesCommon.h"

void init();

#endif